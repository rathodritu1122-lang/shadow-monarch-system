SHADOW SYSTEM — Android Studio project (not a compiled APK)

This project wraps the Shadow System web app in a basic Android WebView shell.

To build an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync and install any requested Android SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Note: This environment did not compile or sign an APK. This is the Android project source, not an installable APK file.
